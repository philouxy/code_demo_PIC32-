# code Demo for PIC32 

Some projects wich use the microcontroller PIC32 with the starterkit developped by the ETML-ES. 
Here, the source files (header and C) which were modified, but not the complet project (for the moment) 

1) First test => active the input/output and the input ADC 


